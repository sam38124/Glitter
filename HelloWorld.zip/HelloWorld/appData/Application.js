function onCreate() {
    //Set up with your first page
    glitter.setHome('HelloWorld.html', 'HelloWorld', '')
}

